# siranap-ws
Integrasi Data dengan Bed Monitoring Yankes Kemenkes 

Menggunakan API URL/ Link Web Service Yang dikembangkan Oleh Rumah Sakit 

Merujuk pada juknis pada http://sirs.yankes.kemkes.go.id/sirsservice/start/ts bagian Bed Monitoring.

Menggunakan Java 1.8 (Java™ Platform, Standard Edition 8)

Cara menggunakan:
1.	Download project https://github.com/dnaftali/siranap-ws
2.	Generate file "siranap.sql" pada server MySQL.
3.	Edit credential dan header pada file "siranap-ws/src/java/siranapws/BedMonitoring.java"
4.	Compile menjadi war.
5.	Upload ke Server Application (misal Apache Tomcat)
