# siranap-hapus
Integrasi Data dengan Bed Monitoring Yankes Kemenkes

Menghapus Data keadaan tempat tidur dari SIMRS Ke Web Service Ditjen Pelayanan Kesehatan. 
Merujuk juknis pada  http://sirs.yankes.kemkes.go.id/sirsservice/start/ts bagian Bed Monitoring.
Menggunakan Java 1.8 (Java™ Platform, Standard Edition 8)
Cara menggunakan:
1.	Download project https://github.com/dnaftali/siranap-hapus 
2.	Edit credential dan header pada file "/src/siranappost/SiranapHapus.java"
3.	Compile menjadi jar.
4.	Jalankan menggunakan perintah: java -jar /dist/SiranapHapus.jar
